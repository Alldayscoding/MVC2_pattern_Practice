package com.example.shoppingmall;

import java.io.*;
import java.util.Enumeration;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.apache.struts2.dispatcher.multipart.JakartaMultiPartRequest;


@WebServlet(name = "helloServlet", value = "/upload.do")
public class HelloServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html; charset=utf-8");

        PrintWriter out = response.getWriter();
        String savePath = "upload"; //저장 경로
        int upLoadFileSizeLimit = 5*1024*1024; //5메가 제한
        String encTytpe = "utf-8";
        ServletContext context = getServletContext();
        String uploadPath = context.getRealPath(savePath);
        System.out.println("서버상 실제 디렉토리 : " + uploadPath);
/*


        try {
            JakartaMultiPartRequest multi = new JakartaMultiPartRequest();


                    request,
                    uploadPath,
                    upLoadFileSizeLimit,
                    encTytpe,
                    new DefaultFileRenamePolicy());


          //  multi.parse(request, uploadPath, upLoadFileSizeLimit, encTytpe, new DefaultFileRenamePolicy());
            Enumeration files = multi.getFilenames();

            String file_name = multi.getFilesystemName(file);
            while(files.hasMoreElements()) {
                String ori_file_name = multi.getOriginalFileName(file);
                out.print("<br> 업로드된 파일명 : " + file_name);
                out.print("<br> 원본 파일명 : " + ori_file_name);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        */
    }
}