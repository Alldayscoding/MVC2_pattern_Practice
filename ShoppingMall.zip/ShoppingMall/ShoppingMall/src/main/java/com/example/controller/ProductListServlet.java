package com.example.controller;

import java.io.IOException;
import java.util.List;

import com.example.dao.ProductDAO;
import com.example.dto.ProductVO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "ProductListServlet", value = "/ProductList.do")
public class ProductListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ProductDAO pDao = ProductDAO.getInstance();
        List<ProductVO> productList = pDao.selectAllProducts();
        request.setAttribute("productList", productList);

        RequestDispatcher dis = request.getRequestDispatcher("product/product.jsp");
        dis.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}